# Cookie Clicker — offline build

Self-contained copy of **Cookie Clicker v2.058** (https://orteil.dashnet.org/cookieclicker/),
stripped of every external dependency so it runs with no network access at all.

## Contents

- `index.html` — entry point
- `main.js`, `style.css`, `base64.js` — game
- `minigame*.js` — Garden, Grimoire, Pantheon, Market
- `loc/EN.js` — English strings (the only localization file shipped)
- `img/`, `snd/` — graphics and audio
- `fonts/` — Merriweather 900 (latin + latin-ext)

## Changes from the official release

- `LOCAL=true` is forced, so the game skips its "wrong address" frame when
  embedded in an iframe, never issues AJAX/JSON requests, and never shows ad layout.
- All ad markup and scripts, cookie-consent, the Facebook pixel and the
  Cloudflare beacon were removed.
- Google Fonts replaced with the two bundled woff2 files.
- Language picker removed from the top bar and the Options menu; the game
  always launches in English. Other `loc/*.js` files are not included.
- Marketing/social links and the "Other versions" menu were removed.

## Notes

- Version is declared in `index.html` (`var VERSION=2.058;`), not in `main.js`.
- Saves use `localStorage` under the key `CookieClickerGame`. If an older save
  from a previous Cookie Clicker build is present on the same origin, it will be
  imported automatically — use **Options → Wipe save** to start fresh.
- Code and graphics copyright Orteil, 2013-2026. Personal/offline use only;
  please do not re-host or redistribute.
